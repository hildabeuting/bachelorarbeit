# Fertige `\cite`-Befehle nach Abschnitt

Alle Seitenzahlen sind gegen Inhaltsverzeichnis, Kolumnentitel oder Sachverzeichnis der Quelldateien geprüft, sofern nicht anders markiert. Zum Einfügen: Zeile kopieren, an die passende Stelle im Fließtext setzen.

**Nicht verifizierbar:** `broughton` liegt nicht im Projekt vor. Alle Seitenzahlen dafür musst du selbst ergänzen — ich habe die Stellen mit `\cite[S.~??]{broughton}` markiert, damit du sie beim Durchgehen nicht übersiehst.

---

## Kapitel 2 — Funktionalanalytische Grundlagen

### 2.1 Der Hilbertraum $L^2(\mathbb{R})$
```latex
\cite[Kap.~25, S.~249--253]{serov}          % Def. 25.1 Skalarprodukt, Def. 25.7 Hilbertraum
\cite[Kap.~2.1, S.~26--27]{blatter}
\cite[\S31, S.~279--280]{hankebourgeois}     % Definition von L^2(Omega)
\cite[Notationen, S.~9--12]{louis}
```

### 2.2 Orthonormalbasen und ihre Charakterisierung
```latex
\cite[Satz~25.18, S.~258]{serov}             % Charakterisierung einer ONB -- Hauptbeleg
\cite[Def.~25.16--25.17, S.~257--258]{serov}
\cite[Satz~25.12, S.~254--255]{serov}        % Projektionssatz (Seite geschätzt)
\cite[Satz~31.6, S.~281]{hankebourgeois}     % nur endlichdimensional!
\cite[Kap.~2.1, S.~27]{blatter}
```

### 2.3 Unitäre Operatoren
```latex
\cite[Def.~27.7 und Bem.~27.8, S.~282]{serov}
\cite[Kap.~1.2, S.~26--29]{louis}            % Dilatations- und Translationsoperator
\cite[Lemma~1.2.1, S.~27]{louis}             % adjungierte affine Operatoren
```

### 2.4 Fourier-Transformation und Satz von Plancherel
```latex
\cite[Satz~17.5, S.~145]{serov}              % Plancherel
\cite[Kap.~5.1, S.~131--144]{steinshakarchi}
\cite[Kap.~2.2, S.~31--42]{blatter}
\cite[S.~36]{blatter}                        % Plancherel-Formel
\cite[Anhang, S.~313--316]{louis}
```

### 2.5 Grenzen der Fourier-Analyse bei nichtstationären Signalen
```latex
\cite[Kap.~1.3.2, S.~36--37]{louis}          % WT vs. gefensterte FT
\cite[Kap.~1.4, S.~10--12]{blatter}
\cite[Kap.~2.3, S.~43--46]{blatter}          % Heisenbergsche Unschärferelation
\cite[Kap.~5.4, S.~158--160]{steinshakarchi}
\cite[Beispiel~52.7 und Abb.~52.1, S.~403--404]{hankebourgeois}   % EKG mit T_8 und T_32
\cite[S.~433--434]{hankebourgeois}           % Fourierkoeffizienten von chi_[a,b] fallen wie 1/k
\cite[Beispiel~56.3 und Abb.~56.2, S.~440]{hankebourgeois}
\cite[Abb.~2.7, S.~22]{rebstadt}
```

---

## Kapitel 3 — CWT zur Multiskalenanalyse

### 3.1 Die kontinuierliche Wavelet-Transformation
```latex
\cite[Def.~1.1.1, S.~18]{louis}              % Zulässigkeitsbedingung
\cite[Kap.~1.1, S.~17--25]{louis}
\cite[Gl.~(1.2.1), S.~27]{louis}
\cite[Kap.~3.1, S.~54--60]{blatter}
\cite[Kap.~3.2, S.~61--64]{blatter}
\cite[Kap.~3.3, S.~65--68]{blatter}          % Umkehrformeln
\cite[Kap.~1.5, S.~48--50]{louis}            % Abklingverhalten
\cite[S.~??]{broughton}
```

### 3.2 Diskretisierung: Frames und Rieszbasen
```latex
\cite[Def.~2.1.1, S.~88]{louis}              % Wavelet-Frame, Schranken A, B
\cite[Kap.~2.1.1, S.~87--104]{louis}
\cite[Satz~2.1.5, S.~92]{louis}
\cite[Satz~2.1.9, S.~96]{louis}
\cite[Kap.~2.1.2, S.~106--109]{louis}        % Frame-Operator
\cite[Kap.~4.1, S.~79--86]{blatter}
\cite[Kap.~4.2, S.~87--90]{blatter}
\cite[S.~80, 87--88]{blatter}                % Frame, Frame-Operator, Riesz-Basis
\cite[S.~??]{broughton}
```

### 3.3 Das dyadische Gitter
```latex
\cite[Def.~2.1.1, S.~88]{louis}              % Gitterparameter a_0, b_0
\cite[Kap.~4.3, S.~91--99]{blatter}
\cite[S.~91, 93, 94]{blatter}                % Grundschritt, zulässiges Wavelet, Parameter
\cite[Kap.~4.4, S.~100--104]{blatter}
\cite[S.~??]{broughton}
\cite[\S56, S.~434]{hankebourgeois}          % Gitterfamilie Omega_k, Gl. (56.1)
```

### 3.4 Multiskalenanalyse: Axiome
```latex
\cite[Def.~2.2.1, S.~111]{louis}             % MSA-Definition
\cite[Bem.~2.2.2, S.~112]{louis}
\cite[Kap.~5.1, S.~106--109]{blatter}
\cite[S.~106]{blatter}                       % MSA, Separations-, Vollständigkeitsaxiom
```
> Hanke-Bourgeois hier **nicht** zitieren: dort steht eine endliche Kette über $[0,1]$, keine MSA in $L^2(\mathbb{R})$.

### 3.5 Skalierungsfunktion und Orthonormalbasis der Räume $V_j$
```latex
\cite[Kap.~5.2, S.~110--116]{blatter}
\cite[Kap.~2.2.1, S.~110--127]{louis}
\cite[Satz~2.2.9, S.~121]{louis}             % Orthogonalitätsbedingungen an H
\cite[Def.~56.1, S.~436]{hankebourgeois}     % Träger
\cite[S.~??]{broughton}
```

### 3.6 Detailräume $W_j$ und die Zerlegung von $L^2(\mathbb{R})$
```latex
\cite[Satz~2.2.10, S.~122]{louis}            % Konstruktion von psi aus phi
\cite[S.~175]{louis}                         % Zerlegung L^2 = V_0 + Summe W_j
\cite[Abb.~2.6, S.~112]{louis}
\cite[Gl.~(56.3), S.~435]{hankebourgeois}    % V_{k+1} = V_k + W_k
\cite[Prop.~56.2, S.~436--437]{hankebourgeois}  % ONB von V_k und W_k, mit Beweis
\cite[Gl.~(56.7), S.~437]{hankebourgeois}    % Multiskalenbasis
\cite[S.~437]{hankebourgeois}                % Zweiskalenbasis, Trend, Fluktuation
\cite[Kap.~5.2--5.3, S.~110--129]{blatter}
\cite[Kap.~2.3.2, S.~21--24]{rebstadt}
```

---

## Kapitel 4 — Konstruktion der DWT

### 4.1 Die Skalierungsgleichung
```latex
\cite[S.~111]{blatter}                       % Skalierungsgleichung
\cite[S.~112]{blatter}                       % Konsistenzbedingungen
\cite[Kap.~2.4.2, S.~145--164]{louis}        % Lösung von Skalierungsgleichungen
\cite[Gl.~(2.4.12), S.~165]{louis}
\cite[Gl.~(56.8), S.~438]{hankebourgeois}    % Haar-Fall explizit
\cite[Gl.~(56.2), S.~434--435]{hankebourgeois}
```

### 4.2 Filterkoeffizienten: Tiefpass und Hochpass
```latex
\cite[Gl.~(2.4.13), S.~165]{louis}           % Spiegelbeziehung g_k = (-1)^k h_{1-k}
\cite[Bem.~2.4.19, S.~165]{louis}            % Conjugate Quadrature Filter (CQF)
\cite[S.~170]{louis}                         % Tabelle der Daubechies-Skalierungskoeffizienten
\cite[Kap.~5.3, S.~117--129]{blatter}
\cite[Gl.~(56.8), S.~438]{hankebourgeois}
\cite[Gl.~(56.9), S.~438]{hankebourgeois}    % Synthesefilter
\cite[S.~55--56]{aqil}                       % Fig. 4/5, HPF/LPF
\cite[Abb.~2.10, S.~27]{rebstadt}
```

### 4.3 Bedingungen im Fourier-Bereich
```latex
\cite[Gl.~(2.4.14), S.~165]{louis}           % H(0)=1, |H(w)|^2+|H(w+pi)|^2=1
\cite[Satz~2.2.9, S.~121]{louis}
\cite[Lemma~2.4.20, S.~166]{louis}
\cite[S.~119]{blatter}                       % erzeugende Funktion
\cite[Kap.~5.3, S.~117--129]{blatter}
```

### 4.4 Der Mallat-Algorithmus
```latex
\cite[Kap.~2.3, S.~132--141]{louis}          % Schnelle Wavelet-Transformation
\cite[Gl.~(2.3.1)--(2.3.2), S.~133]{louis}   % Zerlegungsoperatoren H und G
\cite[Abb.~2.8, S.~133--134]{louis}
\cite[S.~133--135]{louis}                    % Rekonstruktion
\cite[Kap.~5.4, S.~130--136]{blatter}
\cite[S.~15]{blatter}                        % Fast Wavelet Transform
\cite[Gl.~(56.10), S.~438]{hankebourgeois}   % Analyseformeln explizit
\cite[Alg.~56.1, S.~439]{hankebourgeois}     % Pseudocode fhwt / ifhwt
\cite[S.~438]{hankebourgeois}                % Aufwand: billiger als die FFT
\cite[S.~54--56]{aqil}
\cite[Kap.~3, S.~575--577]{chatterjee}
```

### 4.5.1 Kompakter Träger und Filterlänge
```latex
\cite[Satz~2.4.9, S.~153]{louis}             % endlicher Filter => kompakter Träger [0,M]
\cite[Kap.~2.4.3, S.~165--169]{louis}
\cite[S.~175]{louis}                         % supp phi_N = [0,2N-1], supp psi_N = [1-N,N]
\cite[S.~165]{louis}                         % Meyer/Spline haben keinen kompakten Träger
\cite[Kap.~6.1, S.~137--145]{blatter}
\cite[Kap.~6.2, S.~146--153]{blatter}
\cite[S.~151]{blatter}                       % Daubechies-Wavelets
```

### 4.5.2 Verschwindende Momente
```latex
\cite[Satz~2.4.28, S.~174]{louis}            % HAUPTBELEG: Integral x^m psi_N dx = 0
\cite[Lemma~2.4.27, S.~174]{louis}           % diskrete Momentenbedingung
\cite[Lemma~2.4.29, S.~174--175]{louis}      % Polynomreproduktion, Summe phi(x-k)=1
\cite[Lemma~2.4.30, S.~176]{louis}           % Approximationsordnung
\cite[Kap.~1.4.2, S.~45--47]{louis}
\cite[Satz~1.4.2, S.~41]{louis}
\cite[Kap.~3.5, S.~73--78]{blatter}
\cite[S.~74]{blatter}                        % Moment, Ordnung eines Wavelets
```

### 4.5.3 Regularität
```latex
\cite[Satz~2.4.26, S.~173]{louis}            % HAUPTBELEG: Sobolev-Ordnung s < ln N / (2 ln 2)
\cite[Lemma~2.4.24, S.~171]{louis}           % Faktorisierung von H_N
\cite[Satz~2.4.38, S.~183]{louis}            % schärfer: Hölder-Exponent
\cite[Bem.~2.4.39, S.~183]{louis}            % alpha_N ungefähr 0,20775 N
\cite[S.~173]{louis}                         % Vergleich mit B-Splines
\cite[Satz~2.4.34, S.~179]{louis}
\cite[Kap.~6.3, S.~154--163]{blatter}
\cite[Abb.~2.9, S.~25]{rebstadt}
```

---

## Kapitel 5 — Entrauschung durch Thresholding

> Louis/Maaß/Rieder enthält **kein** Thresholding. Kapitel 5 trägt Mallat allein.

### 5.1 Das additive Rauschmodell
```latex
\cite[Kap.~11.1, S.~601--603]{mallat}
\cite[S.~608]{mallat}                        % Kovarianzmatrix sigma^2 Id
\cite[Abb.~2.3, S.~10]{rebstadt}
```

### 5.2 Invarianz weißen Rauschens unter Orthonormaltransformation
```latex
\cite[Kap.~11.2, S.~617]{mallat}
\cite[Def.~27.7, S.~282]{serov}
\cite[Lemma~1.2.1, S.~27]{louis}
```

### 5.3 Dünnbesetztheit von EKG-Signalen im Waveletbereich
```latex
\cite[Kap.~11.2.3, S.~634--636]{mallat}
\cite[S.~619--621]{mallat}                   % Oracle-Projektor, M-Term-Approximation
\cite[Lemma~2.4.30, S.~176]{louis}
\cite[Kap.~3.1.2, S.~239--240]{louis}        % am realen EKG: d^1 fängt das Rauschen auf
\cite[S.~437--438]{hankebourgeois}           % O(log n) statt n Koeffizienten, bewiesen
\cite[Beispiel~56.3, S.~440]{hankebourgeois} % >1/4 der 2048 Waveletkoeffizienten < 10^{-4}
\cite[Kap.~2.3.1, S.~15--20]{rebstadt}
```

### 5.4 Hard- und Soft-Thresholding
```latex
\cite[S.~621--622]{mallat}                   % Gl. (11.47) hard, (11.49) soft
\cite[S.~629]{mallat}                        % Bias durch Amplitudenreduktion
\cite[S.~57]{aqil}                           % Fig. 6
\cite[S.~61--63]{aqil}                       % Fig. 11, empirischer SNR-Vergleich
```

### 5.5 Der Satz von Donoho--Johnstone
```latex
\cite[Satz~11.7, S.~623]{mallat}
\cite[Lemma~11.1, S.~624--625]{mallat}
```

### 5.6.1 VisuShrink
```latex
\cite[S.~625--626]{mallat}
\cite[S.~57--58]{aqil}
\cite[S.~630--631]{mallat}                   % SureShrink zur Einordnung
\cite[S.~637]{mallat}                        % Multiscale SURE
```

### 5.6.2 MAD-Schätzer
```latex
\cite[Gl.~(11.85), S.~636]{mallat}
\cite[S.~635, 637]{mallat}
\cite[Kap.~3.1.2, S.~239]{louis}             % warum d^1 die richtige Skala ist
```

---

## Kapitel 6 — Anwendung

### 6.1.1 Der Herzzyklus
```latex
\cite[Abb.~2.2, S.~28]{gacek}
\cite[Kap.~2.2, S.~24--25]{gacek}
\cite[Abb.~2 und Tab.~1, S.~52]{aqil}
\cite[Kap.~2.1, S.~7--10]{rebstadt}
\cite[S.~239]{louis}
```

### 6.1.2 Typische Störquellen
```latex
\cite[S.~31--33]{gacek}                      % Abb. 2.5, 2.6, 2.7
\cite[Kap.~1.1, S.~570]{chatterjee}
\cite[Abb.~3, S.~54]{aqil}
\cite[Abb.~2.3, S.~10]{rebstadt}
```

### 6.2 Bewertungsmaße
```latex
\cite[Gl.~(56)\,ff., S.~582]{chatterjee}
\cite[S.~59]{aqil}
\cite[Kap.~4.3, S.~54--55]{rebstadt}
```

### 6.2a Warum $a_{0,k} := X(k)$ zulässig ist  *(neuer Abschnitt)*
```latex
\cite[Kap.~3.1.1, S.~237--238]{louis}        % Gl. (3.1.1): f(kh) = s_k + O(h^alpha)
\cite[Bem.~3.1.1, S.~238]{louis}
\cite[Lemma~2.4.29, S.~175]{louis}           % Summe phi(x-k) = 1
```

### 6.3 Stufe 1: Synthetisches EKG-Signal
```latex
\cite[Kap.~3.1.2, S.~238--240]{louis}
\cite[S.~170]{louis}                         % Filterkoeffizienten für die Implementierung
\cite[Alg.~56.1, S.~439]{hankebourgeois}     % Referenzimplementierung Haar
\cite[Kap.~4, S.~61--65]{aqil}
\cite[Kap.~4.1--4.2, S.~49--53]{rebstadt}
\cite[Abb.~11.4--11.5, S.~635, 638]{mallat}
```

### 6.4 Stufe 2: MIT-BIH
```latex
\cite[Kap.~5.1.1, S.~61--62]{rebstadt}
\cite[Tab.~9, S.~586]{chatterjee}
\cite[S.~60--66]{aqil}
```

### 6.5 Stufe 3: Klinische Daten
```latex
\cite[Kap.~3.1.2, S.~239--240]{louis}        % Bewertung ohne SNR
\cite[Abb.~3.3, S.~241]{louis}
\cite[Abb.~56.3, S.~441]{hankebourgeois}     % Zerlegung des EKG-Signals, Trend/Fluktuation
\cite[Kap.~3, S.~46--48]{rebstadt}
\cite[Kap.~4.4, S.~56--59]{rebstadt}
\cite[Kap.~2.4.5\,ff., S.~35--37]{gacek}
```

### 6.6 Diskussion
```latex
\cite[S.~626--627]{mallat}
\cite[S.~238]{louis}
\cite[Kap.~4.4, S.~56--59]{rebstadt}
\cite[Kap.~5, S.~585--587]{chatterjee}
```

---

## Kapitel 7 — Fazit und Ausblick
```latex
\cite[S.~632--633]{mallat}                   % Translation-Invariant Thresholding
\cite[S.~639]{mallat}
\cite[S.~637]{mallat}
\cite[Kap.~2.4.5, S.~184--190]{louis}        % Biorthogonale Wavelets
\cite[Kap.~2.4.7.3, S.~209]{louis}           % Coiflets
\cite[Vorwort, S.~1]{louis}                  % Multiwavelets, Lifting-Prinzip
\cite[Kap.~6.2, S.~76--77]{rebstadt}
\cite[Kap.~5, S.~585--587]{chatterjee}
```
