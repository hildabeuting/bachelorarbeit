# Quellenzuordnung zur Gliederung

*Stand: nach Aufnahme von Louis/Maaß/Rieder*

**Legende Seitenzahlen**
`[bestätigt]` = aus Inhaltsverzeichnis, Kolumnentitel oder Sachverzeichnis der Datei verifiziert
`[geschätzt]` = aus Kapitelgrenzen interpoliert, nicht direkt am Textabschnitt abgelesen
`[LÜCKE]` = im Projekt liegt keine geeignete Quelle vor

**Kurzbelege**
LMR = Louis/Maaß/Rieder, *Wavelets: Theorie und Anwendungen*, 2. Aufl., Teubner 1998 · Blatter = *Wavelets – Eine Einführung*, 2. Aufl. 2003 · Serov = *Fourier Series, Fourier Transform and Their Applications to Mathematical Physics*, AMS 197 · SteinShakarchi = *Fourier Analysis*, Princeton 2003 · HankeBourgeois = *Grundlagen der Numerischen Mathematik und des Wissenschaftlichen Rechnens* · Mallat = *A Wavelet Tour*, Kap. 11 „Denoising", S. 601–640 · Aqil = Aqil/Jbari/Bourouhou, iJOE 13(9), 2017, S. 51–68 · Chatterjee = Chatterjee et al., IET Signal Process. 14(9), 2020, S. 569–590 · Gacek = Gacek, *An Introduction to ECG Signal Processing and Analysis*, Kap. 2, S. 21–46 · Rebstadt = Rebstadt, Masterarbeit HS Darmstadt 2021

---

## 1 Einleitung

**1.1 Motivation: EKG-Signale und ihre Störquellen**
Das EKG ist ein nichtstationäres biomedizinisches Signal, dessen diagnostisch entscheidende Strukturen von Störungen überlagert werden, die im selben Frequenzband liegen wie das Nutzsignal — womit einfache Frequenzfilter ausscheiden.
- **LMR, Kap. 3.1.2 „EKG-Analyse", S. 238–240** `[bestätigt]` — Herzklappenrhythmus und „late potentials" als diagnostische Fragestellungen; Abb. 3.1 (S. 239)
- Gacek, Kap. 2.1, S. 21–22 `[bestätigt]` — diagnostische Bedeutung, historische Einordnung
- Gacek, Kap. 2.3, S. 25–27 `[bestätigt]` — Störquellen im Überblick
- Chatterjee, Kap. 1.1 „Predominant noises in ECG", S. 570 `[bestätigt]`
- Aqil, Kap. 2, S. 53–54 `[bestätigt]` — Fig. 3, Rauschtypen
- Rebstadt, Kap. 2.1, S. 7–11 `[bestätigt]` — Abb. 2.3 (S. 10)

**1.2 Zielsetzung und Abgrenzung**
Ziel ist die mathematisch vollständige Herleitung der DWT-Entrauschung; Abgrenzung gegenüber konkurrierenden Verfahren, die nur benannt werden.
- LMR, Vorwort zur ersten Auflage, S. 3–4 `[bestätigt]` — Verzahnung von Theorie und Anwendung als Programm
- Chatterjee, Kap. 2–4, S. 571–581 `[geschätzt]`
- Rebstadt, Kap. 2.3, S. 14–31 `[bestätigt]`

**1.3 Aufbau der Arbeit**
Reiner Wegweiser, keine Quellen nötig.

---

## 2 Funktionalanalytische Grundlagen

**2.1 Der Hilbertraum L²(ℝ)**
Einführung von L²(ℝ) als vollständigem Raum mit Skalarprodukt — dem Raum, in dem sämtliche Signale und Wavelets im Folgenden leben.
- Serov, Kap. 25, S. 249–253 `[bestätigt]` (Def. 25.1 Skalarprodukt, Def. 25.7 Hilbertraum)
- Blatter, Kap. 2.1, S. 26–27 `[bestätigt]`
- LMR, „Notationen", S. 9–12 `[bestätigt]` — Räume L^p, C_0^∞, S(ℝ), S'(ℝ) in genau der Notation, die LMR durchgehend verwendet

**2.2 Orthonormalbasen und ihre Charakterisierung**
Der zentrale Satz: Vollständigkeit, Parseval-Gleichung und die Entwicklung jedes Elements sind für ein Orthonormalsystem äquivalent.
- **Serov, Satz 25.18 „Characterization of an orthonormal basis", S. 258** `[bestätigt]`
- Serov, Def. 25.16–25.17, S. 257–258 `[bestätigt]`
- Serov, Satz 25.12 (Projektionssatz), S. 254–255 `[geschätzt]`
- Blatter, Kap. 2.1, S. 27 `[bestätigt]`
- **HankeBourgeois, Satz 31.6, S. 281** `[bestätigt]` — (a) Entwicklung, (b) Satz des Pythagoras, (c) Bestapproximation, (d) Besselsche Ungleichung, mit Beweis
- HankeBourgeois, §31 „Innenprodukträume, Orthonormalbasen und Gramsche Matrizen", S. 275–282 `[bestätigt]`; Definition von $L^2(\Omega)$, S. 279–280 `[geschätzt]`

> ⚠️ **HankeBourgeois Satz 31.6 gilt nur für endlichdimensionale Teilräume $X_n \subset X$.** Er ersetzt Serov Satz 25.18 **nicht**, sondern ist dessen endlichdimensionale Vorstufe. Als deutschsprachiger Einstieg und für die Projektion auf $V_j$ (Teil (c)) ist er trotzdem sehr brauchbar — die Aussage für abzählbar unendliche ONB muss aber aus Serov kommen.

**2.3 Unitäre Operatoren**
Ein unitärer Operator ist eine surjektive Isometrie; er erhält Skalarprodukte und damit Energie — der Grund, warum Rauschen unter der DWT seine Statistik behält.
- **Serov, Def. 27.7 und Bem. 27.8, S. 282** `[bestätigt]` (Sachverz.: „unitary operator, 282")
- **LMR, Kap. 1.2 „Affine Operatoren", S. 26–29** `[bestätigt]` — Dilatationsoperator $D_a$, Translationsoperator $T_b$, beide Isometrien mit Bild ganz $L^2$, daher Adjungierte = Inverse
- **LMR, Lemma 1.2.1 (adjungierte affine Operatoren), S. 27** `[bestätigt]`
- LMR, S. 27 `[bestätigt]` — affin-lineare Gruppe $G_{af}$ und Verknüpfungsgesetz $T_{b'}D_{a'}T_bD_a = T_{b'+a'b}D_{aa'}$

> **Empfehlung:** LMR Kap. 1.2 ist hier die bessere Quelle als Serov, weil dort genau die beiden Operatoren behandelt werden, aus denen die Wavelet-Familie aufgebaut ist. Serov Def. 27.7 als allgemeine Definition voranstellen, LMR als Anwendung.

**2.4 Fourier-Transformation und Satz von Plancherel**
Die Fourier-Transformation setzt sich von der Schwartz-Klasse eindeutig zu einem unitären Isomorphismus auf L²(ℝ) fort.
- **Serov, Satz 17.5 (Plancherel), S. 145** `[bestätigt]`
- Serov, Kap. 16–17, S. 133–152 `[bestätigt]`
- SteinShakarchi, Kap. 5.1, S. 131–144 `[bestätigt]`
- Blatter, Kap. 2.2, S. 31–42 `[bestätigt]`; Plancherel-Formel S. 36 `[bestätigt]`
- **LMR, Anhang „Fourier-Transformation", S. 313–316** `[bestätigt]` — kompakte Zusammenstellung genau der Regeln, die LMR im Waveletteil benutzt

**2.5 Grenzen der Fourier-Analyse bei nichtstationären Signalen**
Die Fourier-Basis ist global; sie sagt *welche* Frequenzen auftreten, nicht *wann* — bei einem QRS-Komplex ist genau die Lokalisierung entscheidend.
- **LMR, Kap. 1.3.2 „Wavelet-Transformation und gefensterte Fourier-Transformation", S. 36–37** `[bestätigt]` — direkter Vergleich beider Transformationen, in der 2. Auflage eigens dafür neu aufgenommen
- LMR, Kap. 1.3.1 „Phasenraumdarstellung", S. 30–35 `[bestätigt]`
- LMR, Vorwort zur ersten Auflage, S. 3 `[bestätigt]` — fehlende Lokalisierungseigenschaft der Fourier-Transformation, prägnant formuliert
- Blatter, Kap. 1.4, S. 10–12 `[bestätigt]`; Kap. 2.3 „Heisenbergsche Unschärferelation", S. 43–46 `[bestätigt]`
- SteinShakarchi, Kap. 5.4, S. 158–160 `[bestätigt]`
- **HankeBourgeois, Beispiel 52.7 mit Abbildung 52.1, S. 403–404** `[bestätigt]` — reales EKG-Signal mit $N = 2048$ Meßwerten und seinen Bestapproximationen aus $T_8$ und $T_{32}$; die scharfen Peaks werden mit sinkendem Polynomgrad ausgeglättet, $t_8$ „übersieht" das Minimum am ca. 200. Datenpunkt
- **HankeBourgeois, S. 433–434** `[bestätigt]` — quantitativ: die Fourierkoeffizienten von $\chi_{[a,b]}$ fallen nur wie $1/k$, der $L^2$-Fehler nach $n$ Termen ist $\sim n^{-1/2}$; „schlechte Lokalisierungseigenschaft bezüglich der Ortsvariablen"
- **HankeBourgeois, Beispiel 56.3 mit Abbildung 56.2, S. 440** `[bestätigt]` — Fourier- vs. Waveletkoeffizienten desselben EKG-Signals in logarithmischer Skala
- Rebstadt, Abb. 2.7, S. 22 `[bestätigt]`

> **Fußnote S. 404:** Die EKG-Daten stammen laut HankeBourgeois von **Prof. Dr. P. Maaß, Universität Bremen** — demselben Maaß wie in Louis/Maaß/Rieder. Deine beiden deutschsprachigen Quellen arbeiten am selben Signal.

---

## 3 Von der kontinuierlichen Wavelet-Transformation zur Multiskalenanalyse

**3.1 Die kontinuierliche Wavelet-Transformation**
Definition der CWT über Verschiebung und Skalierung eines Mutter-Wavelets; die Zulässigkeitsbedingung sichert die Umkehrbarkeit.
- **LMR, Definition 1.1.1 (Zulässigkeitsbedingung), S. 18** `[bestätigt]`
- LMR, Kap. 1.1 „Definition und elementare Eigenschaften", S. 17–25 `[bestätigt]`; Satz 1.1.8 S. 18 ff. `[geschätzt]`
- LMR, Gl. (1.2.1), S. 27 `[bestätigt]` — CWT als Skalarprodukte mit $\{T_bD_a\psi\}$
- Blatter, Kap. 3.1, S. 54–60 `[bestätigt]`; Kap. 3.2, S. 61–64 `[bestätigt]`; Kap. 3.3 „Umkehrformeln", S. 65–68 `[bestätigt]`
- LMR, Kap. 1.5 „Abklingverhalten", S. 48–50 `[bestätigt]`
- Aqil, Kap. 2, S. 55 `[bestätigt]` — Gl. (2)

**3.2 Diskretisierung: Frames und Rieszbasen**
Die CWT ist hochgradig redundant; Frames formalisieren stabile, aber überbestimmte Darstellungen, Rieszbasen den Übergang zur Minimalität.
- **LMR, Definition 2.1.1 (Wavelet-Frame mit Schranken A, B; festes Frame für A = B), S. 88** `[bestätigt]`
- LMR, Kap. 2.1.1 „Einführung und Definition", S. 87–104 `[bestätigt]`; Satz 2.1.5, S. 92 `[bestätigt]`; Satz 2.1.9, S. 96 `[bestätigt]`; Beispiele, S. 105 `[bestätigt]`
- **LMR, Kap. 2.1.2 „Der Frame-Operator", S. 106–109** `[bestätigt]`
- Blatter, Kap. 4.1, S. 79–86 `[bestätigt]`; Kap. 4.2, S. 87–90 `[bestätigt]`
- Blatter, S. 80, 87–88 `[bestätigt]` (Sachverz.: „Frame 80, 87", „Frame-Operator 80, 88", „Riesz-Basis 88", „straffes Frame 82", „duales Frame 85")

> **Terminologie beachten:** LMR sagt „festes Frame" (tight), Blatter „straffes Frame". Einmal festlegen und bei der jeweils anderen Quelle in Klammern ergänzen.

**3.3 Das dyadische Gitter**
Beschränkung auf Skalen 2^j und Verschiebungen k·2^j — kritische Abtastung, die die Redundanz genau auf null reduziert.
- LMR, Definition 2.1.1, S. 88 `[bestätigt]` — Gitterparameter $a_0 > 1$, $b_0 > 0$; der dyadische Fall $a_0 = 2$ als Spezialfall
- Blatter, Kap. 4.3, S. 91–99 `[bestätigt]`; S. 91, 93, 94 `[bestätigt]` (Sachverz.)
- Blatter, Kap. 4.4 „Beweis des Satzes (4.10)", S. 100–104 `[bestätigt]`

**3.4 Multiskalenanalyse: Axiome**
Die MSA als aufsteigende Kette abgeschlossener Teilräume mit Skalierungs-, Separations- und Vollständigkeitseigenschaft, erzeugt von einer einzigen Funktion.
- **LMR, Definition 2.2.1 (MSA), S. 111** `[bestätigt]` — Kette $\{0\} \subset \dots \subset V_1 \subset V_0 \subset V_{-1} \subset \dots \subset L^2$, Bedingungen (2.2.2)–(2.2.5)
- **LMR, Bemerkung 2.2.2, S. 112** `[bestätigt]` — Deutung der Grenzübergänge $m \to \pm\infty$
- **Blatter, Kap. 5.1 „Axiomatische Beschreibung", S. 106–109** `[bestätigt]`
- Blatter, S. 106 `[bestätigt]` (Sachverz.: „MSA 106", „Separationsaxiom 106", „Vollständigkeitsaxiom 106")
- HankeBourgeois, §56, S. 434–435 `[bestätigt]` — Gitterfamilie $\Omega_k$ (Gl. 56.1) und Treppenfunktionenräume $V_0 \subset V_1 \subset \dots \subset V_p$

> ⚠️ **HankeBourgeois realisiert keine MSA im Sinne von Kapitel 3.** Dort steht eine **endliche** Kette über $[0,1]$, nicht die beidseitig unendliche Kette in $L^2(\mathbb{R})$. Die Axiome (Separation, Vollständigkeit) tauchen gar nicht auf, weil sie im endlichen Fall trivial sind. Für 3.4 also **nur** Blatter und LMR zitieren; HankeBourgeois gehört in Kapitel 4 und 6.

> **Wichtiger Unterschied, den du benennen solltest:** LMR fordert in (2.2.5) von den Translaten $\varphi(\cdot-k)$ nur eine **Riesz-Basis** von $V_0$ (mit Konstanten $A, B > 0$), Blatter dagegen direkt eine **Orthonormalbasis**. LMR ist die allgemeinere Fassung; die Orthonormalisierung ist ein eigener Schritt. Das erklärt den Übergang, den du in Block C bislang implizit vollzogen hast.

**3.5 Skalierungsfunktion und Orthonormalbasis der Räume V_j**
Aus einer einzigen Funktion φ entsteht durch Skalieren und Verschieben eine Basis jedes V_j — hier liegt der noch offene Vollständigkeitsschritt.
- **Blatter, Kap. 5.2 „Die Skalierungsfunktion", S. 110–116** `[bestätigt]`
- LMR, Kap. 2.2.1, S. 110–127 `[bestätigt]`
- **LMR, Satz 2.2.9, S. 121** `[bestätigt]` — Orthogonalitätsbedingungen an das Fourier-Filter einer orthogonalen Skalierungsfunktion
- HankeBourgeois, Def. 56.1 (Träger), S. 436 `[bestätigt]`

**3.6 Detailräume W_j und die Zerlegung von L²(ℝ)**
W_j als orthogonales Komplement von V_j in V_{j−1}; die direkte Summe aller W_j ergibt ganz L²(ℝ).
- **LMR, Satz 2.2.10, S. 122** `[bestätigt]` — Konstruktion des Wavelets ψ aus φ, das $W_m$ aufspannt
- LMR, S. 175 `[bestätigt]` — die Zerlegung $L^2(\mathbb{R}) = V_0 \oplus \bigoplus_{j \le 0} W_j$ explizit verwendet
- LMR, Abbildung 2.6, S. 112 `[bestätigt]` — Zerlegung eines Signals in $P_2f$, $Q_0f$, $Q_1f$
- Blatter, Kap. 5.2–5.3, S. 110–129 `[bestätigt]` (Kapitelgrenzen), konkrete Sätze `[geschätzt]`
- **HankeBourgeois, Gl. (56.3), S. 435** `[bestätigt]` — $V_{k+1} = V_k \oplus W_k$ als Zerlegung in nieder- und hochfrequenten Anteil
- **HankeBourgeois, Proposition 56.2, S. 436–437** `[bestätigt]` — $\{\chi_{kj}\}$ und $\{\psi_{kj}\}$ sind Orthonormalbasen von $V_k$ bzw. $W_k$, mit vollständigem, elementarem Beweis
- **HankeBourgeois, Gl. (56.7), S. 437** `[bestätigt]` — Multiskalenbasis $V_p = V_0 \oplus W_0 \oplus \dots \oplus W_{p-1}$
- HankeBourgeois, S. 437 `[bestätigt]` — Begriffe **Zweiskalenbasis**, **Trend** (Anteil in $V_k$) und **Fluktuation** (Anteil in $W_k$)
- Rebstadt, Kap. 2.3.2, S. 21–24 `[bestätigt]` — Abb. 2.8

---

## 4 Konstruktion der diskreten Wavelet-Transformation

**4.1 Die Skalierungsgleichung**
Da φ ∈ V₀ ⊂ V_{−1} liegt, lässt es sich in der Basis von V_{−1} entwickeln — daraus folgt die Zwei-Skalen-Gleichung mit den Koeffizienten h_k.
- **Blatter, S. 111** `[bestätigt]` (Sachverz.: „Skalierungsgleichung 111"); **S. 112** `[bestätigt]` („Konsistenzbedingungen 112")
- **LMR, Kap. 2.4.2 „Lösung von Skalierungsgleichungen", S. 145–164** `[bestätigt]` — der Existenzfrage eigens gewidmeter Abschnitt
- LMR, Gl. (2.4.12), S. 165 `[bestätigt]` — Skalierungsgleichung in der Form $\varphi(x)=\sqrt{2}\sum_{k=0}^{M} h_k \varphi(2x-k)$
- Blatter, Kap. 5.2, S. 110–116 `[bestätigt]`
- **HankeBourgeois, Gl. (56.8), S. 438** `[bestätigt]` — die Skalierungsgleichung im Haar-Fall vollständig explizit: $\sqrt{2}\,\chi_{kj} = \chi_{k+1,2j} + \chi_{k+1,2j+1}$
- HankeBourgeois, Gl. (56.2), S. 434–435 `[bestätigt]` — Stauchung und Translation als erzeugende Operationen

**4.2 Filterkoeffizienten: Tiefpass und Hochpass**
Die h_k wirken als Tiefpass, die über g_k = (−1)^k h_{1−k} gewonnenen Koeffizienten als Hochpass — die DWT ist damit eine Filterbank.
- **LMR, Gl. (2.4.13), S. 165** `[bestätigt]` — $\psi(x)=\sqrt{2}\sum_{k=1-M}^{1}(-1)^k h_{1-k}\,\varphi(2x-k)$, also die Spiegelbeziehung explizit
- **LMR, Bemerkung 2.4.19, S. 165** `[bestätigt]` — Filter mit (2.4.14) heißen in der Signalverarbeitung *Conjugate Quadrature Filter* (CQF); die Brücke zur ingenieurwissenschaftlichen Literatur
- **LMR, Tabelle der Daubechies-Skalierungskoeffizienten, S. 170** `[bestätigt]` — direkt für deine Implementierung verwendbar
- Blatter, Kap. 5.3, S. 117–129 `[bestätigt]`
- Aqil, Kap. 2, S. 55–56 `[bestätigt]` — Fig. 4/5, HPF/LPF
- Rebstadt, Abb. 2.10 „Filterbank-Schema", S. 27 `[bestätigt]`
- **HankeBourgeois, Gl. (56.8), S. 438** `[bestätigt]` — Tiefpass $\sqrt{2}\,\chi_{kj} = \chi_{k+1,2j}+\chi_{k+1,2j+1}$ und Hochpass $\sqrt{2}\,\psi_{kj} = \chi_{k+1,2j}-\chi_{k+1,2j+1}$, also $h = (1,1)/\sqrt2$, $g = (1,-1)/\sqrt2$
- HankeBourgeois, Gl. (56.9), S. 438 `[bestätigt]` — die Umkehrung, d. h. die Synthesefilter

**4.3 Bedingungen im Fourier-Bereich**
Übersetzung der Orthonormalität in Bedingungen an das trigonometrische Polynom H: H(0) = 1 und |H(ω)|² + |H(ω+π)|² = 1.
- **LMR, Gl. (2.4.14), S. 165** `[bestätigt]` — beide Bedingungen in genau dieser Form
- **LMR, Satz 2.2.9, S. 121** `[bestätigt]` — Herleitung aus der Orthogonalität
- LMR, Lemma 2.4.20, S. 166 `[bestätigt]` — Charakterisierung von $q(\omega)=|H(\omega)|^2$
- LMR, Satz 2.4.3, S. 146–147 `[geschätzt]`; Satz 2.4.7, S. 149 `[geschätzt]` — hinreichende Bedingungen an $\{h_k\}$
- **Blatter, S. 119** `[bestätigt]` (Sachverz.: „erzeugende Funktion 119")
- Blatter, Kap. 5.3, S. 117–129 `[bestätigt]`; Meyer-Wavelet S. 125 `[bestätigt]`

**4.4 Der Mallat-Algorithmus**
**4.4.1 Zwei-Skalen-Relation zwischen den Stufen** · **4.4.2 Analyse: Approximations- und Detailkoeffizienten** · **4.4.3 Synthese: Rekonstruktionsformel**
Die Skalierungsgleichung, rekursiv über die Stufen angewandt, liefert Faltung mit anschließender Dezimierung (Analyse) bzw. Aufweitung mit Filterung (Synthese) — ein Algorithmus in O(N).
- **LMR, Kap. 2.3 „Schnelle Wavelet-Transformation", S. 132–141** `[bestätigt]`
- **LMR, S. 133** `[bestätigt]` — Zerlegungsoperatoren $H$ und $G$ in Gl. (2.3.1)/(2.3.2), Faltungssymbol $*_2$ = Faltung mit Sub-Sampling um Faktor 2; ausdrücklicher Verweis auf Mallats Originalarbeit
- **LMR, Abbildung 2.8, S. 133–134** `[bestätigt]` — Schema der Zerlegung über M Skalen
- LMR, S. 133–135 `[bestätigt]` — Rekonstruktion aus $c^1$ und $d^1$ über die orthogonale Zerlegung $V_0 = V_1 \oplus W_1$
- **Blatter, Kap. 5.4 „Algorithmen", S. 130–136** `[bestätigt]`
- Blatter, S. 15 `[bestätigt]` (Sachverz.: „Fast Wavelet Transform 15", „FWT 15")
- **HankeBourgeois, Gl. (56.10), S. 438** `[bestätigt]` — die Analyseformeln explizit: $\xi_{kj} = (\xi_{k+1,2j}+\xi_{k+1,2j+1})/\sqrt2$, $\eta_{kj} = (\xi_{k+1,2j}-\xi_{k+1,2j+1})/\sqrt2$
- **HankeBourgeois, Algorithmus 56.1 „Schnelle Haar-Wavelet-Transformation", S. 439** `[bestätigt]` — rekursiver Pseudocode `fhwt` und `ifhwt`, direkt implementierbar
- **HankeBourgeois, Aufwandsanalyse, S. 438** `[bestätigt]` — $2\dim V_p$ Multiplikationen und Additionen, „noch billiger zu implementieren als die fft"
- Aqil, Kap. 2, S. 54–56 `[bestätigt]`
- Chatterjee, Kap. 3, S. 575–577 `[bestätigt]`

> **LMR ist hier deine Hauptquelle.** Die Herleitung über die Operatoren $H$, $G$ ist knapper und algorithmisch klarer als Blatter Kap. 5.4 und lässt sich eins zu eins in NumPy übersetzen.

**4.5 Daubechies-Wavelets**

**4.5.1 Kompakter Träger und Filterlänge**
Endlich viele nichtverschwindende h_k ⇔ kompakter Träger von φ und ψ ⇔ endliche Filterlänge — die Voraussetzung dafür, dass der Mallat-Algorithmus überhaupt implementierbar ist.
- **LMR, Satz 2.4.9, S. 153** `[bestätigt]` — endliche Koeffizientenfolge $\{h_k\}$ ⇒ kompakter Träger $[0,M]$ der Lösung der Skalierungsgleichung
- **LMR, Kap. 2.4.3 „Orthogonale Wavelets mit kompaktem Träger", S. 165–169** `[bestätigt]` — vollständige Konstruktion
- **LMR, S. 175** `[bestätigt]` — die Träger explizit: $\operatorname{supp}\varphi_N = [0,\,2N-1]$, $\operatorname{supp}\psi_N = [1-N,\,N]$
- LMR, S. 165 `[bestätigt]` — Meyer- und Spline-Wavelets haben *keinen* kompakten Träger (die Motivation des ganzen Abschnitts)
- Blatter, Kap. 6.1 „Lösungsansatz", S. 137–145 `[bestätigt]`; Kap. 6.2, S. 146–153 `[bestätigt]`
- **Blatter, S. 151** `[bestätigt]` (Sachverz.: „Daubechies-Wavelets 151")

**4.5.2 Verschwindende Momente**
Ein Wavelet der Ordnung N annulliert alle Polynome vom Grad < N — glatte Signalanteile erzeugen dann kleine Koeffizienten, was die Dünnbesetztheit erst herstellt.
- **LMR, Satz 2.4.28, S. 174** `[bestätigt]` — $\int_{\mathbb{R}} x^m \psi_N(x)\,dx = 0$ für $m = 0,\dots,N-1$, mit vollständigem Beweis
- **LMR, Lemma 2.4.27, S. 174** `[bestätigt]` — die diskrete Momentenbedingung $\sum_k k^m g_k^N = 0$, auf der der Beweis aufbaut
- **LMR, Lemma 2.4.29, S. 174–175** `[bestätigt]` — Polynomreproduktion: $\sum_k c_k^m \varphi_N(x-k) = x^m$, insbesondere $\sum_k \varphi_N(x-k) = 1$ (Gl. 2.4.17)
- **LMR, Lemma 2.4.30, S. 176** `[bestätigt]` — Approximationsordnung $\|P_jf - f\|$ als quantitative Folge der verschwindenden Momente
- LMR, Lemma 2.4.32, S. 177 `[geschätzt]`; Bemerkung S. 176 `[bestätigt]` — die Momenteneigenschaft gilt nicht nur für Daubechies-Wavelets
- LMR, Kap. 1.4.2 „Bemerkungen zur Ordnung von Wavelets", S. 45–47 `[bestätigt]`
- LMR, Satz 1.4.2, S. 41 `[bestätigt]` — Wavelet der Ordnung N im Sobolev-Kontext
- Blatter, Kap. 3.5 „Abklingverhalten", S. 73–78 `[bestätigt]`; **S. 74** `[bestätigt]` (Sachverz.: „Moment 74", „Ordnung eines Wavelets 74")

> **Die Lücke ist geschlossen.** Satz 2.4.28 mit Lemma 2.4.27 ist ein vollständiger, beweisfertiger Block auf gut zwei Seiten — genau das Niveau, das Block D/E braucht.

**4.5.3 Regularität**
Höhere Filterordnung erkauft mehr Glattheit von φ und ψ, aber auch längeren Träger — der Trade-off, der die Wahl der Ordnung begründet.
- **LMR, Satz 2.4.26, S. 173** `[bestätigt]` — Abklingen $|\hat\varphi_N(\omega)| = O(|\omega|^{-1/2-\ln N/(4\ln 2)+\varepsilon})$ und Sobolev-Ordnung $\psi_N \in H^s$ mit $s < \ln N/(2\ln 2)$
- **LMR, Lemma 2.4.24, S. 171** `[bestätigt]` — Faktorisierung des Fourier-Filters $H_N$, technisches Kernstück
- **LMR, Satz 2.4.38 und Bemerkung 2.4.39, S. 183** `[bestätigt]` — der schärfere Hölder-Exponent, asymptotisch $\alpha_N \approx 0{,}20775\cdot N$
- LMR, S. 173 `[bestätigt]` — expliziter Vergleich mit B-Splines ($\alpha = 1$): Daubechies-Regularität wächst linear, aber deutlich langsamer
- LMR, Satz 2.4.34, S. 179 `[bestätigt]`
- Blatter, Kap. 6.3 „Binäre Interpolation", S. 154–163 `[bestätigt]`
- Rebstadt, Abb. 2.9, S. 25 `[bestätigt]`

> **Auch diese Lücke ist geschlossen** — und zwar doppelt: eine einfache Abschätzung (Satz 2.4.26) und eine verfeinerte (Satz 2.4.38). Für eine Bachelorarbeit genügt Satz 2.4.26 mit Beweis, Satz 2.4.38 als zitierte Verschärfung.

---

## 5 Entrauschung durch Thresholding

> ⚠️ **LMR enthält kein Thresholding und kein Denoising.** Suchbegriffe wie „Schwellenwert", „Threshold" oder „Entrauschen" kommen im gesamten Buch nicht vor. Kapitel 5 stützt sich weiterhin allein auf Mallat.

**5.1 Das additive Rauschmodell**
X = f + W mit weißem Gaußschen Rauschen der Varianz σ² — das Modell, unter dem alle folgenden Optimalitätsaussagen gelten.
- **Mallat, Kap. 11.1, S. 601–603** `[bestätigt]` (Gl. 11.1–11.3)
- Mallat, S. 608 `[bestätigt]` — Kovarianzmatrix σ²·Id
- Rebstadt, Abb. 2.3, S. 10 `[bestätigt]`

**5.2 Invarianz weißen Rauschens unter Orthonormaltransformation**
Weißes Rauschen bleibt in *jeder* Orthonormalbasis weiß mit derselben Varianz — deshalb beeinflusst die Basiswahl nur das Signal, nicht das Rauschen.
- **Mallat, Kap. 11.2, S. 617** `[bestätigt]`
- Serov, Def. 27.7, S. 282 `[bestätigt]` — unitäre Invarianz als funktionalanalytische Grundlage
- LMR, Lemma 1.2.1, S. 27 `[bestätigt]` — Isometrieeigenschaft der beteiligten Operatoren

**5.3 Dünnbesetztheit von EKG-Signalen im Waveletbereich**
Stückweise reguläre Signale mit isolierten Singularitäten konzentrieren ihre Energie auf wenige große Koeffizienten — beim EKG ist der QRS-Komplex genau eine solche Singularität.
- **Mallat, Kap. 11.2.3, S. 634–636** `[bestätigt]`
- Mallat, S. 619–621 `[bestätigt]` — Oracle-Projektor, M-Term-Approximation
- **LMR, Lemma 2.4.30, S. 176** `[bestätigt]` — die Approximationsordnung, die der Dünnbesetztheit mathematisch zugrunde liegt
- **LMR, Kap. 3.1.2, S. 239–240** `[bestätigt]` — am realen EKG: $d^1$ fängt praktisch das gesamte Rauschen auf, das Nutzsignal sitzt in wenigen Koeffizienten gröberer Skalen
- **HankeBourgeois, Beispiel S. 437–438** `[bestätigt]` — für $\chi_{[a,b]}$ genügen in der Haar-Multiskalenbasis $O(\log n)$ Koeffizienten für dieselbe Genauigkeit $O(n^{-1/2})$, für die trigonometrische Basis sind es $n$; Beweis über Satz 31.6 (c) und den kompakten Träger
- **HankeBourgeois, Beispiel 56.3, S. 440** `[bestätigt]` — am EKG-Signal quantifiziert: über ein Viertel der 2048 Waveletkoeffizienten liegt betragsmäßig unter $10^{-4}$, aber nur 24 Fourierkoeffizienten (< 1,2 %)
- Rebstadt, Kap. 2.3.1, S. 15–20 `[bestätigt]`

**5.4 Hard- und Soft-Thresholding**
Hard-Thresholding setzt kleine Koeffizienten auf null und lässt große unverändert; Soft-Thresholding schrumpft zusätzlich alle Amplituden um T und erkauft Stetigkeit mit systematischer Verzerrung.
- **Mallat, S. 621–622** `[bestätigt]` (Gl. 11.47 hard, 11.49 soft)
- Mallat, S. 629 `[bestätigt]` — Bias durch Amplitudenreduktion
- Aqil, Kap. 2, S. 57 `[bestätigt]` — Fig. 6; S. 61–63 `[bestätigt]` — Fig. 11, empirischer SNR-Vergleich

**5.5 Der Satz von Donoho–Johnstone**
Für T = σ·√(2 log N) bleibt das Risiko des Thresholding-Schätzers bis auf den Faktor (2 log N + 1) am Oracle-Risiko — und dieser Faktor ist asymptotisch nicht verbesserbar.
- **Mallat, Satz 11.7, S. 623** `[bestätigt]`
- Mallat, Lemma 11.1 und Beweis, S. 624–625 `[bestätigt]`

**5.6 Wahl des Schwellenwerts**

**5.6.1 VisuShrink**
Die universelle Schwelle folgt daraus, dass das Maximum von N unabhängigen Gaußvariablen mit hoher Wahrscheinlichkeit unter σ√(2 log N) bleibt.
- **Mallat, S. 625–626** `[bestätigt]`
- Aqil, „Threshold selection", S. 57–58 `[bestätigt]`
- SureShrink zur Einordnung: Mallat, S. 630–631 `[bestätigt]`; Multiscale-SURE, S. 637 `[bestätigt]`

**5.6.2 Schätzung der Rauschstärke: der MAD-Schätzer**
σ ist in der Praxis unbekannt und wird robust aus dem Median der Betragswerte der feinsten Detailkoeffizienten geschätzt, geteilt durch 0.6745.
- **Mallat, Gl. (11.85), S. 636** `[bestätigt]`
- Mallat, S. 635, 637 `[bestätigt]` — Robustheit, skalenweise Anwendung
- **LMR, Kap. 3.1.2, S. 239** `[bestätigt]` — Begründung, warum gerade $d^1$ die richtige Skala für die Schätzung ist

---

## 6 Anwendung: Entrauschung von EKG-Signalen

**6.1 EKG-Signale: Morphologie und Störquellen**

**6.1.1 Der Herzzyklus: P-Welle, QRS-Komplex, T-Welle**
Die P-Welle entspricht der Vorhoferregung, der QRS-Komplex der Kammerdepolarisation, die T-Welle der Repolarisation.
- **Gacek, Abb. 2.2, S. 28** `[bestätigt]`
- Gacek, Kap. 2.2, S. 24–25 `[bestätigt]`
- Aqil, Abb. 2 und Tab. 1, S. 52 `[bestätigt]`
- Rebstadt, Kap. 2.1, S. 7–10 `[bestätigt]` — Abb. 2.1 (S. 8), Abb. 2.2 (S. 10)
- **LMR, S. 239** `[bestätigt]` — knappe mathematiknahe Beschreibung: Hauptmuskelkontraktion als ausgeprägtes Maximum, Herzklappenausschläge „fast im Rauschen versteckt"

**6.1.2 Typische Störquellen**
Baseline Wander, Muskelartefakte, Netzbrummen (50/60 Hz) und additives weißes Rauschen.
- **Gacek, S. 31–33** `[bestätigt]` — Abb. 2.5, 2.6, 2.7
- Chatterjee, Kap. 1.1, S. 570 `[bestätigt]`
- Aqil, Abb. 3, S. 54 `[bestätigt]`
- Rebstadt, Abb. 2.3, S. 10 `[bestätigt]`

**6.2 Bewertungsmaße und das Problem der fehlenden Referenz**
SNR, MSE und PRD setzen ein rauschfreies Referenzsignal voraus, das bei realen Messungen prinzipiell nicht existiert.
- **Chatterjee, Gl. (56) ff., S. 582** `[bestätigt]`
- Aqil, Kap. 3, S. 59 `[bestätigt]`
- Rebstadt, Kap. 4.3, S. 54–55 `[bestätigt]`

**6.2a Vorverarbeitung: warum a_{0,k} := X(k) zulässig ist** *(neu einzufügen)*
Die Abtastwerte $s_k$ dürfen als Skalierungskoeffizienten der Stufe 0 gelesen werden, weil für hölderstetige Signale und eine Skalierungsfunktion mit kompaktem Träger und $\sum_k\varphi(x-k)=1$ der Fehler nur $O(h^\alpha)$ beträgt.
- **LMR, Kap. 3.1.1 „Vorbereitungen", S. 237–238** `[bestätigt]` — die beiden Vorverarbeitungsschritte, Gl. (3.1.1): $\tilde f(kh) = s_k + O(h^\alpha)$
- **LMR, Bemerkung 3.1.1, S. 238** `[bestätigt]` — Quadraturformeln höherer Ordnung, falls die Fehlerordnung nicht genügt
- LMR, Lemma 2.4.29 / Gl. (2.4.17), S. 175 `[bestätigt]` — die dabei benötigte Bedingung $\sum_k\varphi(x-k)=1$
- LMR, Aufgabe 3.1, S. 311 `[geschätzt]` — der Beweis von (3.1.1) ist dort als Übung gestellt

**6.3 Stufe 1: Synthetisch konstruiertes EKG-Signal**
**6.3.1 Konstruktion des Modellsignals** · **6.3.2 Rauschmodell und Wahl der Parameter** · **6.3.3 Wahl von Wavelet und Zerlegungstiefe** · **6.3.4 Vergleich von Hard- und Soft-Thresholding** · **6.3.5 Ergebnisse**
Kontrollierte Umgebung mit bekanntem f: erlaubt exakte SNR-Messung und damit die numerische Überprüfung der Theorie aus Kapitel 5.
- **LMR, Kap. 3.1.2, S. 238–240** `[bestätigt]` — methodisches Vorbild: ein einzelner Herzschlag, MSA über vier Stufen, Histogramme der Koeffizienten (Abb. 3.2, S. 240)
- LMR, Tabelle der Skalierungskoeffizienten, S. 170 `[bestätigt]` — Filterkoeffizienten für die Implementierung
- Aqil, Kap. 4, S. 61–65 `[bestätigt]` — Fig. 9, 11, 14, Tab. 4
- Rebstadt, Kap. 4.1–4.2, S. 49–53 `[bestätigt]` — Abb. 4.1 (S. 50)
- Mallat, Abb. 11.4–11.5, S. 635, 638 `[bestätigt]`
- Eigene Implementierung (NumPy) — keine Fremdquelle

**6.4 Stufe 2: Reale Daten aus der MIT-BIH-Datenbank**
**6.4.1 Beschreibung des Datensatzes** · **6.4.2 Validierung ohne sauberes Referenzsignal** · **6.4.3 Ergebnisse**
Standardisierte, annotierte EKG-Aufzeichnungen; da kein rauschfreies Original existiert, wird künstliches Rauschen additiv aufgeprägt.
- **Rebstadt, Kap. 5.1.1, S. 61–62** `[bestätigt]` — Abb. 5.1, Datensatz 205
- Chatterjee, Tab. 9, S. 586 `[bestätigt]`
- Aqil, Kap. 3–4, S. 60–66 `[bestätigt]`

**6.5 Stufe 3: Klinische Daten des Herzzentrums**
**6.5.1 Datensatz und Vorverarbeitung** · **6.5.2 Anwendung der Verarbeitungskette** · **6.5.3 Ergebnisse und Grenzen der Beurteilbarkeit**
Ungefilterte Realdaten ohne jede Referenz — Bewertung nur qualitativ bzw. über die Erhaltung diagnostischer Merkmale möglich.
- **LMR, Kap. 3.1.2, S. 239–240** `[bestätigt]` — genau dieser Fall: Bewertung über die Sichtbarkeit des Herzklappenrhythmus auf Skala $m=3$, ohne SNR
- LMR, Abb. 3.3, S. 241 `[bestätigt]` — $|d^3|^2$ auf exponentieller Skala, Maxima als Zeitpunkte der Herzklappenaktivität
- **HankeBourgeois, Abbildung 56.3, S. 441** `[bestätigt]` — rekursive Waveletzerlegung des EKG-Signals, Trend und Fluktuation für $k = 7$ bis $k = 2$ untereinander dargestellt; direkte Vorlage für deine eigene Zerlegungsabbildung
- Rebstadt, Kap. 3, S. 46–48 `[bestätigt]` — Abb. 3.1 (S. 48)
- Rebstadt, Kap. 4.4, S. 56–59 `[bestätigt]` — Auswertung ohne Referenz über Power Spectral Density (Abb. 4.8, S. 58)
- Gacek, Kap. 2.4.5 ff., S. 35–37 `[bestätigt]`

**6.6 Diskussion**
Wo bestätigt das Experiment die Theorie, wo nicht — und welche Modellannahmen sind bei echten EKGs verletzt.
- Mallat, S. 626–627 `[bestätigt]` — skalenabhängige Rauschvarianz, Grenzen der universellen Schwelle
- LMR, S. 238 `[bestätigt]` — die Wahl von Skalierungsfunktion, Wavelet und Filtern „verlangt unter Umständen einiges Fingerspitzengefühl"; ehrliche Einordnung der Theoriegrenzen aus mathematischer Feder
- Rebstadt, Kap. 4.4, S. 56–59 `[bestätigt]` — die DWT wurde dort von einem konkurrierenden Verfahren geschlagen
- Chatterjee, Kap. 5, S. 585–587 `[bestätigt]`

---

## 7 Fazit und Ausblick

Zusammenfassung des Argumentationsbogens und Ausblick auf translationsinvariantes Thresholding, adaptive Schwellen und konkurrierende Zerlegungen.
- **Mallat, „Translation-Invariant Thresholding", S. 632–633** `[bestätigt]`; S. 639 `[bestätigt]`
- Mallat, „Multiscale Sure Thresholds", S. 637 `[bestätigt]`
- LMR, Kap. 2.4.5 „Biorthogonale Wavelets", S. 184–190 `[bestätigt]`; Kap. 2.4.7.3 „Coiflets", S. 209 `[bestätigt]` — naheliegende Erweiterungen der Basiswahl
- LMR, Vorwort zur zweiten Auflage, S. 1 `[bestätigt]` — Multiwavelets und das Lifting-Prinzip als weiterführende Richtungen
- Rebstadt, Kap. 6.2, S. 76–77 `[bestätigt]`
- Chatterjee, Kap. 5, S. 585–587 `[bestätigt]`

---

## Offene Punkte

1. ~~Lücke bei 4.5.2 und 4.5.3~~ — **geschlossen** durch LMR Satz 2.4.28 (S. 174) und Satz 2.4.26 (S. 173).
2. **Kap. 5 bleibt einquellig.** LMR enthält kein Thresholding; Mallat Kap. 11 trägt das Kapitel allein. Falls der Betreuer eine zweite Quelle verlangt, wäre die Originalarbeit von Donoho–Johnstone nachzuladen.
3. **Notationsfalle Daubechies-Ordnung.** LMR bezeichnet mit $N$ die Zahl der verschwindenden Momente; die Filterlänge ist $2N$. Das Wavelet, das LMR in der EKG-Analyse verwendet („mit 4 Koeffizienten", S. 239), ist also $N=2$ — in der PyWavelets-Nomenklatur `db2`, **nicht** `db4`. Vor dem Schreiben einmal eine Konvention festlegen und im Text explizit ansagen.
4. **Indexkonvention — jetzt eindeutig entschieden.** LMR (Def. 2.2.1, S. 111) und Blatter (Kap. 5.1, S. 106) stimmen überein: wachsender Index bedeutet **gröber** ($V_1 \subset V_0 \subset V_{-1}$). HankeBourgeois (S. 434) läuft genau andersherum: $V_0 \subset V_1 \subset \dots \subset V_p$, wachsender Index bedeutet **feiner**. Steht 2:1 — folge Blatter/LMR und setze bei jedem HankeBourgeois-Zitat die Übersetzung dazu.
9. **HankeBourgeois §59 „Ein Anwendungsbeispiel", S. 453–462, ist für dich irrelevant** — es behandelt ein elektrostatisches Randwertproblem und Matrixkompression im Wavelet-Galerkin-Verfahren, kein EKG. Nicht zitieren.
5. **MSA-Definition.** LMR (Def. 2.2.1, S. 111) fordert nur eine Riesz-Basis, Blatter eine ONB. In 3.4 als bewusste Wahl kenntlich machen.
6. **Offener Cauchy-Folgen-Schritt** in 3.5 — mit dem Betreuer klären.
7. **Neuer Abschnitt 6.2a** vorgeschlagen: die Rechtfertigung von $a_{0,k} := X(k)$ über LMR Gl. (3.1.1), S. 237–238. Bislang war das in Block E eine unbegründete Setzung.
8. Alle mit `[geschätzt]` markierten Seitenzahlen vor Abgabe am gedruckten Buch nachschlagen.
